G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4-10.0.4~ubuntu25.10.1*
G04 #@! TF.CreationDate,2026-09-22T19:25:01+00:00*
G04 #@! TF.ProjectId,main-board,6d61696e-2d62-46f6-9172-642e6b696361,f67273a*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4-10.0.4~ubuntu25.10.1) date 2026-09-22 19:25:01*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
